document.getElementById("clickMe").addEventListener("click", function() {
    alert("Button Clicked!");
});
